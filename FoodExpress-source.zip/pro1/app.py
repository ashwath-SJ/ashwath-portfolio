from flask import Flask, render_template, request, jsonify
from database import connection, cursor

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/menu")
def menu():
    return render_template("menu.html")


@app.route("/cart")
def cart():
    return render_template("cart.html")


@app.route("/checkout")
def checkout():
    return render_template("checkout.html")


@app.route("/place_order", methods=["POST"])
def place_order():

    data = request.get_json()

    name = data["name"]
    phone = data["phone"]
    address = data["address"]
    payment = data["payment"]
    total = data["total"]

    sql = """
    INSERT INTO orders
    (customer_name, phone, address, payment, total)
    VALUES (%s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (name, phone, address, payment, total))
    connection.commit()

    return jsonify({
        "message": "Order Placed Successfully!"
    })


if __name__ == "__main__":
    app.run(debug=True)
    