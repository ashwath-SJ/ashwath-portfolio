import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="ashwath74@74",
    database="food_deliveryy"
)

cursor = connection.cursor()