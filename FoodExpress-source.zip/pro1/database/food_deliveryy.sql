CREATE DATABASE IF NOT EXISTS food_deliveryy;

USE food_deliveryy;

CREATE TABLE orders (

    id INT AUTO_INCREMENT PRIMARY KEY,

    customer_name VARCHAR(100),

    phone VARCHAR(20),

    address TEXT,

    payment VARCHAR(30),

    total DECIMAL(10,2),

    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);