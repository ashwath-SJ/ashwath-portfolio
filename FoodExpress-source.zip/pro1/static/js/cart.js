// ================= GET CART =================

let cart = JSON.parse(localStorage.getItem("cart")) || [];

const cartContainer = document.getElementById("cart-items");

const total = document.getElementById("total");


// ================= LOAD CART =================

function loadCart() {

    cartContainer.innerHTML = "";

    let grandTotal = 0;


    // Empty cart

    if (cart.length === 0) {

        cartContainer.innerHTML = `
            <div class="empty-cart">

                <h3>Your cart is empty.</h3>

                <p>Add some delicious food from our menu!</p>

                <a href="/menu" class="btn">
                    Browse Menu
                </a>

            </div>
        `;

        total.innerHTML = "0";

        return;
    }


    // Display items

    cart.forEach((food, index) => {

        grandTotal += Number(food.price);


        cartContainer.innerHTML += `

            <div class="cart-item">

                <img
                    src="${food.image}"
                    alt="${food.name}"
                >


                <div class="cart-details">

                    <h3>
                        ${food.name}
                    </h3>

                    <p>
                        Price : ₹${food.price}
                    </p>

                </div>


                <button
                    class="remove-btn"
                    onclick="removeItem(${index})">

                    Remove

                </button>

            </div>

        `;

    });


    // Show total

    total.innerHTML = grandTotal;

}


// ================= REMOVE ITEM =================

function removeItem(index) {

    cart.splice(index, 1);

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    loadCart();

}


// ================= LOAD WHEN PAGE OPENS =================

loadCart();