// ================= FOOD DATA =================

const foods = [

    {
        id: 1,
        name: "Pizza",
        price: 199,
        category: "Pizza",
        image: "/static/images/pizza.jpg"
    },

    {
        id: 2,
        name: "Burger",
        price: 149,
        category: "Burger",
        image: "/static/images/burger.jpg"
    },

    {
        id: 3,
        name: "Chicken Biryani",
        price: 249,
        category: "Biryani",
        image: "/static/images/biryani.jpg"
    },

    {
        id: 4,
        name: "Sandwich",
        price: 99,
        category: "Burger",
        image: "/static/images/sandwich.jpg"
    },

    {
        id: 5,
        name: "French Fries",
        price: 89,
        category: "Burger",
        image: "/static/images/fries.jpg"
    },

    {
        id: 6,
        name: "Fried Chicken",
        price: 299,
        category: "Chicken",
        image: "/static/images/fried-chicken.jpg"
    }

];


// ================= MENU CONTAINER =================

const menu = document.getElementById("menu-container");


// ================= DISPLAY FOOD =================

function displayFood(items) {

    menu.innerHTML = "";

    if (items.length === 0) {

        menu.innerHTML = `
            <div class="no-food">
                <h3>No food items found</h3>
                <p>Try another category or search.</p>
            </div>
        `;

        return;
    }


    items.forEach(food => {

        menu.innerHTML += `

            <div class="food-card">

                <img src="${food.image}" alt="${food.name}">

                <h3>${food.name}</h3>

                <p>₹${food.price}</p>

                <button
                    class="add-btn"
                    onclick="addToCart(${food.id})">

                    Add to Cart

                </button>

            </div>

        `;

    });

}


// ================= INITIAL DISPLAY =================

displayFood(foods);


// ================= ADD TO CART =================

function addToCart(id) {

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    const food = foods.find(item => item.id === id);

    if (!food) {
        return;
    }

    cart.push(food);

    localStorage.setItem("cart", JSON.stringify(cart));

    updateCart();

    alert(food.name + " added to cart");

}


// ================= UPDATE CART COUNT =================

function updateCart() {

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    const cartCount = document.getElementById("cart-count");

    if (cartCount) {

        cartCount.innerHTML = cart.length;

    }

}


// ================= CATEGORY FILTER =================

function filterCategory(category) {

    // Remove active class from all buttons

    const buttons = document.querySelectorAll(".category-btn");

    buttons.forEach(button => {

        button.classList.remove("active");

    });


    // Add active class to selected button

    buttons.forEach(button => {

        if (button.innerText.toLowerCase().includes(category.toLowerCase())) {

            button.classList.add("active");

        }

    });


    // Show all foods

    if (category === "All") {

        displayFood(foods);

        return;

    }


    // Filter foods

    const filteredFoods = foods.filter(food => {

        return food.category === category;

    });


    displayFood(filteredFoods);

}


// ================= SEARCH =================

document.getElementById("search").addEventListener("keyup", function () {

    const value = this.value.toLowerCase();


    const result = foods.filter(food => {

        return food.name.toLowerCase().includes(value);

    });


    displayFood(result);

});


// ================= CART COUNT ON PAGE LOAD =================

updateCart();