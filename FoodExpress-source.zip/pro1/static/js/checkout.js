// ================= GET CART =================

let cart = JSON.parse(localStorage.getItem("cart")) || [];


// ================= ELEMENTS =================

const summaryContainer =
    document.getElementById("order-summary-items");

const checkoutTotal =
    document.getElementById("checkout-total");

const checkoutTotalForm =
    document.getElementById("checkout-total-form");

const deliveryTime =
    document.getElementById("delivery-time");


// ================= CALCULATE TOTAL =================

let total = 0;

cart.forEach(item => {

    total += Number(item.price);

});


// ================= ORDER SUMMARY =================

function displayOrderSummary() {

    summaryContainer.innerHTML = "";


    // No items

    if (cart.length === 0) {

        summaryContainer.innerHTML = `
            <p>
                Your cart is empty.
            </p>

            <a href="/menu" class="btn">
                Go to Menu
            </a>
        `;

        return;
    }


    // Display every item

    cart.forEach(item => {

        summaryContainer.innerHTML += `

            <div class="summary-item">

                <div>

                    <strong>
                        ${item.name}
                    </strong>

                    <p>
                        ₹${item.price}
                    </p>

                </div>

            </div>

        `;

    });

}


// ================= DISPLAY TOTAL =================

checkoutTotal.innerHTML = total;

checkoutTotalForm.innerHTML = total;


// ================= DELIVERY TIME =================

function calculateDeliveryTime() {

    if (cart.length === 0) {

        deliveryTime.innerHTML =
            "Add food to your cart first.";

        return;

    }


    // Simple delivery estimate

    let minimumTime = 30;

    let maximumTime = 40;


    // Add a few minutes for larger orders

    if (cart.length >= 4) {

        minimumTime = 40;
        maximumTime = 50;

    }


    deliveryTime.innerHTML =
        minimumTime + " - " + maximumTime + " minutes";

}


// ================= SHOW SUMMARY =================

displayOrderSummary();

calculateDeliveryTime();


// ================= CHECKOUT FORM =================

document
    .getElementById("checkout-form")
    .addEventListener("submit", async function (e) {

        e.preventDefault();


        // Don't allow checkout with empty cart

        if (cart.length === 0) {

            alert("Your cart is empty. Please add food first.");

            window.location.href = "/menu";

            return;

        }


        // Get customer information

        const name =
            document.getElementById("name").value.trim();

        const phone =
            document.getElementById("phone").value.trim();

        const address =
            document.getElementById("address").value.trim();

        const payment =
            document.getElementById("payment").value;


        // Order data

        const orderData = {

            name: name,

            phone: phone,

            address: address,

            payment: payment,

            total: total

        };


        try {

            // Send data to Flask

            const response = await fetch(
                "/place_order",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify(orderData)
                }
            );


            // Check server response

            if (!response.ok) {

                throw new Error(
                    "Server error: " + response.status
                );

            }


            const result =
                await response.json();


            // Show confirmation

            alert(

                "Order Placed Successfully!\n\n" +

                "Customer : " + name +

                "\nPhone : " + phone +

                "\nPayment : " + payment +

                "\nTotal : ₹" + total +

                "\nDelivery : " +
                deliveryTime.innerText

            );


            // Clear cart

            localStorage.removeItem("cart");


            // Return home

            window.location.href = "/";

        }


        catch (error) {

            console.error(
                "Order Error:",
                error
            );

            alert(
                "Unable to place order.\n" +
                "Please check whether Flask and MySQL are running."
            );

        }

    });